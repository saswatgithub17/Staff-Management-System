// lib/mis/mobile/mis_home.dart
import 'package:flutter/material.dart';

class MISHome extends StatelessWidget {
  const MISHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes & Assignment'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Mobile view for MIS'),
            ElevatedButton(
              onPressed: () {
                // Navigate to different sections as needed
              },
              child: const Text('Go to Reports'),
            ),
          ],
        ),
      ),
    );
  }
}