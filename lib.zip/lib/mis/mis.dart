// lib/mis/mis.dart
import 'package:flutter/material.dart';
import 'desktop/homescreen.dart' as desktop;
import 'mobile/mis_home.dart' as mobile;

class MIS extends StatelessWidget {
  final bool isDarkMode;

  const MIS({super.key, required this.isDarkMode});

  @override
  Widget build(BuildContext context) {
    // Use layout builder to determine screen size
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 600) {
          // Desktop view
          return desktop.HomeScreen(isDarkMode: isDarkMode, onToggleTheme: () {});
        } else {
          // Mobile view
          return const mobile.MISHome();
        }
      },
    );
  }
}