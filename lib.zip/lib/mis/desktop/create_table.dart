import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CreateTableScreen extends StatefulWidget {
  const CreateTableScreen({super.key, required bool isDarkMode});

  @override
  State<CreateTableScreen> createState() => _CreateTableScreenState();
}

class _CreateTableScreenState extends State<CreateTableScreen> {
  // Form state
  String _selectedBatch = '';
  String _selectedYear = '';
  String _selectedSemester = '';
  final List<Map<String, dynamic>> _subjects = [];

  // Controllers
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _unitController = TextEditingController();

  // API state
  bool _isLoading = false;
  String _apiMessage = '';
  bool _apiSuccess = false;

  // Options
  final List<String> _batches = ['BCA', 'BSc.cs', 'BBA'];
  final List<String> _years = ['2022-2025', '2023-2026', '2024-2027'];
  final List<String> _semesters = ['1st Sem', '2nd Sem', '3rd Sem', '4th Sem', '5th Sem', '6th Sem'];

  @override
  void dispose() {
    _subjectController.dispose();
    _unitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            _buildHeader(),
            const SizedBox(height: 32),

            // Form
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Selection Row
                    _buildSelectionRow(),
                    const SizedBox(height: 24),

                    // Subject Input
                    _buildSubjectInput(),
                    const SizedBox(height: 24),

                    // Subjects List
                    if (_subjects.isNotEmpty) _buildSubjectsList(),

                    // API Response
                    if (_apiMessage.isNotEmpty) _buildApiResponse(),
                  ],
                ),
              ),
            ),

            // Create Button
            _buildCreateButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Create New Table',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Setup notes and assignments tracking for a semester',
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildSelectionRow() {
    return Row(
      children: [
        // Batch Dropdown
        Expanded(
          child: _buildDropdown(
            label: 'Batch',
            value: _selectedBatch,
            items: _batches,
            onChanged: (value) => setState(() => _selectedBatch = value!),
          ),
        ),
        const SizedBox(width: 16),

        // Year Dropdown
        Expanded(
          child: _buildDropdown(
            label: 'Year',
            value: _selectedYear,
            items: _years,
            onChanged: (value) => setState(() => _selectedYear = value!),
          ),
        ),
        const SizedBox(width: 16),

        // Semester Dropdown
        Expanded(
          child: _buildDropdown(
            label: 'Semester',
            value: _selectedSemester,
            items: _semesters,
            onChanged: (value) => setState(() => _selectedSemester = value!),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 4),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey[300]!),
            borderRadius: BorderRadius.circular(8),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButton<String>(
            value: value.isEmpty ? null : value,
            hint: Text('Select $label'),
            underline: const SizedBox(),
            isExpanded: true,
            style: const TextStyle(color: Colors.black87),
            dropdownColor: Colors.white,
            items: items.map((item) => DropdownMenuItem(
              value: item,
              child: Text(item),
            )).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }

  Widget _buildSubjectInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Add Subjects',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              flex: 3,
              child: TextField(
                controller: _subjectController,
                decoration: InputDecoration(
                  hintText: 'Subject name',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 1,
              child: TextField(
                controller: _unitController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: 'Units',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
            ),
            const SizedBox(width: 12),
            IconButton(
              icon: Container(
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.all(8),
                child: const Icon(Icons.add, color: Colors.white),
              ),
              onPressed: _addSubject,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSubjectsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16),
        Text(
          'Added Subjects',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: Colors.grey[700],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey[200]!),
            borderRadius: BorderRadius.circular(8),
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _subjects.length,
            separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey[200]),
            itemBuilder: (context, index) {
              final subject = _subjects[index];
              return ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                title: Text(
                  subject['name'],
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
                subtitle: Text('${subject['units']} units'),
                trailing: IconButton(
                  icon: const Icon(Icons.close, color: Colors.grey),
                  onPressed: () => _removeSubject(index),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildApiResponse() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _apiSuccess ? Colors.green[50] : Colors.red[50],
        border: Border.all(
          color: _apiSuccess ? Colors.green[100]! : Colors.red[100]!,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(
            _apiSuccess ? Icons.check_circle : Icons.error,
            color: _apiSuccess ? Colors.green : Colors.red,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _apiMessage,
              style: TextStyle(
                color: _apiSuccess ? Colors.green[800] : Colors.red[800],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _validateAndSubmit,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: _isLoading
            ? const SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: Colors.white,
          ),
        )
            : const Text(
          'CREATE TABLE',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  void _addSubject() {
    final name = _subjectController.text.trim();
    final units = _unitController.text.trim();

    if (name.isEmpty || units.isEmpty) {
      _showMessage('Please enter both subject name and units');
      return;
    }

    final unitCount = int.tryParse(units);
    if (unitCount == null || unitCount <= 0) {
      _showMessage('Please enter a valid number of units');
      return;
    }

    setState(() {
      _subjects.add({
        'name': name,
        'units': unitCount,
      });
      _subjectController.clear();
      _unitController.clear();
      _apiMessage = ''; // Clear previous API message
    });
  }

  void _removeSubject(int index) {
    setState(() {
      _subjects.removeAt(index);
    });
  }

  Future<void> _validateAndSubmit() async {
    if (_selectedBatch.isEmpty) {
      _showMessage('Please select a batch');
      return;
    }
    if (_selectedYear.isEmpty) {
      _showMessage('Please select a year range');
      return;
    }
    if (_selectedSemester.isEmpty) {
      _showMessage('Please select a semester');
      return;
    }
    if (_subjects.isEmpty) {
      _showMessage('Please add at least one subject');
      return;
    }

    await _submitToApi();
  }

  Future<void> _submitToApi() async {
    setState(() {
      _isLoading = true;
      _apiMessage = '';
    });

    try {
      final url = Uri.parse('https://creativecollege.in/MIS/MIS/api/create_tables.php');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'batch': _selectedBatch,
          'year': _selectedYear,
          'semester': _selectedSemester,
          'subjects': _subjects,
        }),
      );

      final responseData = jsonDecode(response.body);

      setState(() {
        _apiSuccess = responseData['status'] == 'success';
        _apiMessage = responseData['message'] ??
            (_apiSuccess ? 'Table created successfully' : 'Operation failed');
      });

    } catch (e) {
      setState(() {
        _apiSuccess = false;
        _apiMessage = 'Network error: ${e.toString()}';
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}