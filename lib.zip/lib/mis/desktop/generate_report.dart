// generate_report.dart
import 'package:flutter/material.dart';

class GenerateReportScreen extends StatefulWidget {
  final bool isDarkMode;

  const GenerateReportScreen({super.key, required this.isDarkMode});

  @override
  State<GenerateReportScreen> createState() => _GenerateReportScreenState();
}

class _GenerateReportScreenState extends State<GenerateReportScreen> {
  String selectedBatch = 'Batch';
  String selectedYear = 'Year';
  String selectedSemester = 'Semester';
  String selectedType = 'Report Type';

  final List<String> batches = ['Batch', '2021', '2022', '2023'];
  final List<String> years = ['Year', '1st Year', '2nd Year', '3rd Year'];
  final List<String> semesters = ['Semester', 'Sem 1', 'Sem 2', 'Sem 3'];
  final List<String> types = ['Report Type', 'Attendance Report', 'Assignment Summary', 'Marks Report'];

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDarkMode;

    return Scaffold(
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: isDark ? Colors.black : Colors.black,
            child: const Center(
              child: Text(
                "Notes and Assignment",
                style: TextStyle(fontSize: 22, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 30),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Colors.black, Colors.grey]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                dropdownBox(batches, selectedBatch, (val) => setState(() => selectedBatch = val!)),
                dropdownBox(years, selectedYear, (val) => setState(() => selectedYear = val!)),
                dropdownBox(semesters, selectedSemester, (val) => setState(() => selectedSemester = val!)),
                dropdownBox(types, selectedType, (val) => setState(() => selectedType = val!)),
              ],
            ),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              elevation: 5,
              shadowColor: Colors.black,
              textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            child: const Text("Submit"),
          ),
        ],
      ),
    );
  }

  Widget dropdownBox(List<String> items, String selected, ValueChanged<String?> onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        border: Border.all(color: Colors.black54),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selected,
        underline: Container(),
        dropdownColor: Theme.of(context).cardColor,
        items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
        onChanged: onChanged,
      ),
    );
  }
}