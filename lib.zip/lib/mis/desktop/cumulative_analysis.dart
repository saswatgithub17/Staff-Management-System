import 'package:flutter/material.dart';

class CumulativeAnalysisScreen extends StatefulWidget {
  final bool isDarkMode;

  const CumulativeAnalysisScreen({super.key, required this.isDarkMode});

  @override
  State<CumulativeAnalysisScreen> createState() => _CumulativeAnalysisScreenState();
}

class _CumulativeAnalysisScreenState extends State<CumulativeAnalysisScreen> {
  String selectedBatch = 'Select Batch';
  String selectedYear = 'Select Year';
  String selectedSemester = 'Select Semester';
  String selectedType = 'Select Type';

  final List<String> batches = ['Select Batch', '2021', '2022', '2023'];
  final List<String> years = ['Select Year', '1st Year', '2nd Year', '3rd Year'];
  final List<String> semesters = ['Select Semester', 'Sem 1', 'Sem 2', 'Sem 3'];
  final List<String> types = ['Select Type', 'Marks', 'Attendance', 'Assignment'];

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDarkMode;

    return Scaffold(
      backgroundColor: isDark ? Colors.black : Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title Bar
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: isDark ? Colors.black : Colors.grey[900],
            child: const Center(
              child: Text(
                "Notes and assignment",
                style: TextStyle(fontSize: 22, color: Colors.white),
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Subheading
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Colors.indigo, Colors.blueGrey]),
            ),
            child: const Text(
              "Cumulative Report",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),

          const SizedBox(height: 20),

          // Dropdowns
          Center(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Colors.black87, Colors.grey]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  dropdownBox(batches, selectedBatch, (val) => setState(() => selectedBatch = val!)),
                  const SizedBox(width: 10),
                  dropdownBox(years, selectedYear, (val) => setState(() => selectedYear = val!)),
                  const SizedBox(width: 10),
                  dropdownBox(semesters, selectedSemester, (val) => setState(() => selectedSemester = val!)),
                  const SizedBox(width: 10),
                  dropdownBox(types, selectedType, (val) => setState(() => selectedType = val!)),
                ],
              ),
            ),
          ),

          const SizedBox(height: 30),

          // Submit Button
          Center(
            child: ElevatedButton(
              onPressed: () {
                // Add action here
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                elevation: 4,
              ),
              child: const Text("Submit"),
            ),
          ),
        ],
      ),
    );
  }

  Widget dropdownBox(List<String> items, String selected, ValueChanged<String?> onChanged) {
    final isDark = widget.isDarkMode;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isDark ? Colors.black : Colors.white,
        border: Border.all(color: Colors.black54),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selected,
        underline: Container(),
        dropdownColor: isDark ? Colors.grey[850] : Colors.white,
        style: TextStyle(color: isDark ? Colors.white : Colors.black),
        items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
        onChanged: onChanged,
      ),
    );
  }
}
