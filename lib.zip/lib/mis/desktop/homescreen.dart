import 'package:flutter/material.dart';
import 'create_table.dart';
import 'insert.dart';
import 'generate_report.dart';
import 'defaulterreport.dart';
import 'cumulative_analysis.dart';
import 'placeholder_screen.dart';
import 'delete_table.dart';


class HomeScreen extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback onToggleTheme;

  const HomeScreen({
    Key? key,
    required this.isDarkMode,
    required this.onToggleTheme,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      CreateTableScreen(isDarkMode: widget.isDarkMode),         // index 0
      const InsertScreen(),                                     // index 1
      GenerateReportScreen(isDarkMode: widget.isDarkMode),      // index 2
      DefaultersTrackingScreen(isDarkMode: widget.isDarkMode),  // index 3
      CumulativeAnalysisScreen(isDarkMode: widget.isDarkMode),  // index 4
      DeleteTableScreen(isDarkMode: widget.isDarkMode),         // index 5 ✅ add here
    ];


    return Scaffold(
      body: Row(
        children: [
          // Sidebar
          Container(
            width: 230,
            color: Colors.black87,
            child: Column(
              children: [
                const SizedBox(height: 30),
                const Text(
                  "SMS",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 20),
                const CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 40, color: Colors.black),
                ),
                const SizedBox(height: 10),
                const Text('Demo Staff Name', style: TextStyle(color: Colors.white)),
                const Text('Admin', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 30),

                // Navigation buttons
                sidebarButton(Icons.table_chart, 'Create Tables', 0),
                sidebarButton(Icons.storage, 'Insert Data', 1),
                sidebarButton(Icons.receipt_long, 'Generate Report', 2),
                sidebarButton(Icons.disabled_by_default_outlined, 'Defaulters Tracking', 3),
                sidebarButton(Icons.analytics_sharp, 'Cumulative Analysis', 4),
                sidebarButton(Icons.delete, 'Delete Tables', 5),


                const Spacer(),

                // Theme Switch
                SwitchListTile(
                  value: widget.isDarkMode,
                  onChanged: (_) => widget.onToggleTheme(),
                  title: const Text("Dark Mode", style: TextStyle(color: Colors.white)),
                  secondary: Icon(
                    widget.isDarkMode ? Icons.dark_mode : Icons.light_mode,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),

          // Main Area
          Expanded(child: screens[selectedIndex]),
        ],
      ),
    );
  }

  Widget sidebarButton(IconData icon, String title, int index) {
    final isSelected = selectedIndex == index;

    return InkWell(
      onTap: () => setState(() => selectedIndex = index),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.white24,
          borderRadius: BorderRadius.circular(8),
        ),
        child: ListTile(
          leading: Icon(icon, color: Colors.black),
          title: Text(title, style: const TextStyle(color: Colors.black)),
        ),
      ),
    );
  }
}
