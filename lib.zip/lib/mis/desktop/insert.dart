// insert.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class InsertScreen extends StatefulWidget {
  const InsertScreen({Key? key}) : super(key: key);

  @override
  State<InsertScreen> createState() => _InsertScreenState();
}

class _InsertScreenState extends State<InsertScreen> {
  String selectedBatch = 'BCA';
  String selectedYear = '2022-25';
  String selectedSemester = '1st Sem';
  String selectedType = 'notes';
  String selectedSubject = 'all';
  String csrfToken = '';

  bool isLoading = false;
  bool showDataTable = false;
  bool showSubjectFilter = false;

  List<dynamic> tableData = [];
  List<String> subjects = [];
  Map<String, dynamic> formData = {};

  final List<String> batches = ['BCA', 'BSC-C', 'BBA'];
  final List<String> years = ['2022-25', '2023-26', '2024-28'];
  final List<String> semesters = [
    '1st Sem', '2nd Sem', '3rd Sem', '4th Sem',
    '5th Sem', '6th Sem', '7th Sem', '8th Sem'
  ];
  final List<String> types = ['notes', 'assignment', 'project'];

  @override
  void initState() {
    super.initState();
    _generateCsrfToken();
  }

  void _generateCsrfToken() {
    setState(() {
      csrfToken = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
    });
  }

  Future<void> fetchData() async {
    if (selectedBatch.isEmpty || selectedYear.isEmpty || selectedSemester.isEmpty || selectedType.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select Batch, Year, Semester, and Data Type')),
      );
      return;
    }

    setState(() {
      isLoading = true;
      showDataTable = false;
      showSubjectFilter = false;
    });

    try {
      final url = Uri.parse('https://creativecollege.in/MIS/MIS/api/insert.php?batch=$selectedBatch&year=$selectedYear&semester=$selectedSemester&data_type=$selectedType');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 1) {
          setState(() {
            tableData = data['data'];
            subjects = List<String>.from(data['subjects'] ?? []);
            csrfToken = data['csrf_token'] ?? csrfToken;

            if (selectedType != 'project') {
              showSubjectFilter = true;
            } else {
              showDataTable = true;
            }
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['message'] ?? 'Failed to fetch data')),
          );
        }
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> updateData() async {
    setState(() {
      isLoading = true;
    });

    try {
      final url = Uri.parse('https://creativecollege.in/MIS/MIS/api/insert.php');
      final headers = {'Content-Type': 'application/json'};

      final body = {
        'batch': selectedBatch,
        'year': selectedYear,
        'semester': selectedSemester,
        'data_type': selectedType,
        'subject_filter': selectedSubject,
        'csrf_token': csrfToken,
        'data': formData,
      };

      if (selectedType == 'project') {
        body.addAll({
          'topic_coverage': formData['topic_coverage'] ?? {},
          'competence': formData['competence'] ?? {},
          'language': formData['language'] ?? {},
          'delivery': formData['delivery'] ?? {},
          'time_management': formData['time_management'] ?? {},
          'sum': formData['sum'] ?? {},
          'total': formData['total'] ?? {},
        });
      }

      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(body),
      );

      final responseData = json.decode(response.body);
      if (responseData['status'] == 1) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(responseData['message'] ?? 'Data updated successfully')),
        );
        fetchData(); // Refresh data after update
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(responseData['message'] ?? 'Failed to update data')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _handleCheckboxChange(String studentId, String column, bool value, String dateColumn) {
    setState(() {
      formData[studentId] ??= {};
      formData[studentId][column] = value ? 'YES' : 'NO';

      if (value) {
        formData[studentId][dateColumn] = DateTime.now().toString().split(' ')[0];
      } else {
        formData[studentId][dateColumn] = '';
      }
    });
  }

  void _handleDateChange(String studentId, String dateColumn, String value) {
    setState(() {
      formData[studentId] ??= {};
      formData[studentId][dateColumn] = value;
    });
  }

  void _handleProjectScoreChange(String studentId, String field, String value) {
    setState(() {
      formData[studentId] ??= {};
      formData[studentId][field] = value.isEmpty ? 0 : int.parse(value);

      // Calculate sum and total for project evaluation
      if (field == 'topic_coverage' || field == 'competence' ||
          field == 'language' || field == 'delivery' || field == 'time_management') {

        int sum = 0;
        for (var criterion in ['topic_coverage', 'competence', 'language', 'delivery', 'time_management']) {
          sum += int.tryParse(formData[studentId][criterion]?.toString() ?? '0') ?? 0;
        }

        formData[studentId]['sum'] = sum;
        formData[studentId]['total'] = sum * 4;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).primaryColorDark,
            child: Center(
              child: Text(
                selectedType == 'notes' ? 'NOTES INFORMATION' :
                selectedType == 'assignment' ? 'ASSIGNMENT INFORMATION' :
                'PROJECT EVALUATION',
                style: const TextStyle(fontSize: 22, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedBatch,
                    decoration: InputDecoration(
                      labelText: 'Batch',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    items: batches.map((batch) {
                      return DropdownMenuItem(
                        value: batch,
                        child: Text(batch),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedBatch = value!;
                        showDataTable = false;
                        showSubjectFilter = false;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedYear,
                    decoration: InputDecoration(
                      labelText: 'Year',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    items: years.map((year) {
                      return DropdownMenuItem(
                        value: year,
                        child: Text(year),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedYear = value!;
                        showDataTable = false;
                        showSubjectFilter = false;
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedSemester,
                    decoration: InputDecoration(
                      labelText: 'Semester',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    items: semesters.map((semester) {
                      return DropdownMenuItem(
                        value: semester,
                        child: Text(semester),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedSemester = value!;
                        showDataTable = false;
                        showSubjectFilter = false;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedType,
                    decoration: InputDecoration(
                      labelText: 'Data Type',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    items: types.map((type) {
                      return DropdownMenuItem(
                        value: type,
                        child: Text(type[0].toUpperCase() + type.substring(1)),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedType = value!;
                        showDataTable = false;
                        showSubjectFilter = false;
                      });
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: isLoading ? null : fetchData,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: isLoading
                ? const CircularProgressIndicator(color: Colors.white)
                : const Text('Show Data', style: TextStyle(color: Colors.white)),
          ),
          const SizedBox(height: 20),
          if (showSubjectFilter && subjects.isNotEmpty && selectedType != 'project')
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Select Subject to View',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: selectedSubject,
                            decoration: InputDecoration(
                              labelText: 'Subject',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: 'all',
                                child: Text('All Subjects'),
                              ),
                              ...subjects.map((subject) {
                                return DropdownMenuItem(
                                  value: subject,
                                  child: Text(subject),
                                );
                              }).toList(),
                            ],
                            onChanged: (value) {
                              setState(() {
                                selectedSubject = value!;
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              showDataTable = true;
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: const Text('View Data', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (isLoading)
            const Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(),
            ),
          if (showDataTable && tableData.isNotEmpty)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Card(
                  elevation: 3,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          'Batch: $selectedBatch | Semester: $selectedSemester',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: DataTable(
                              columns: _buildDataColumns(),
                              rows: _buildDataRows(),
                              headingRowColor: MaterialStateProperty.resolveWith<Color>(
                                      (Set<MaterialState> states) => Colors.grey[200]!),
                              dataRowHeight: 60,
                              headingRowHeight: 40,
                              showBottomBorder: true,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: ElevatedButton(
                          onPressed: isLoading ? null : updateData,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: isLoading
                              ? const CircularProgressIndicator(color: Colors.white)
                              : const Text('Update Data', style: TextStyle(color: Colors.white)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  List<DataColumn> _buildDataColumns() {
    if (tableData.isEmpty) return [];

    List<DataColumn> columns = [
      const DataColumn(label: Text('Roll No')),
      const DataColumn(label: Text('Name')),
    ];

    if (selectedType == 'project') {
      columns.addAll([
        const DataColumn(label: Text('Topic Coverage')),
        const DataColumn(label: Text('Competence')),
        const DataColumn(label: Text('Language')),
        const DataColumn(label: Text('Delivery')),
        const DataColumn(label: Text('Time Mgmt')),
        const DataColumn(label: Text('Sum')),
        const DataColumn(label: Text('Total')),
      ]);
    } else {
      // For notes and assignments
      final firstRow = tableData.first;
      final dataKeys = firstRow.keys.where((key) =>
      !['id', 'name', 'batch', 'year', 'semester'].contains(key) &&
          (selectedType == 'notes' ? key.contains('note') : key.contains('assignment'))).toList();

      for (var key in dataKeys) {
        if (selectedSubject != 'all' && !key.toLowerCase().contains(selectedSubject.toLowerCase().replaceAll(' ', '_'))) {
          continue;
        }

        if (key.endsWith('_date')) continue;

        columns.add(DataColumn(label: Text(key.replaceAll('_', ' '))));
      }
    }

    return columns;
  }

  List<DataRow> _buildDataRows() {
    return tableData.map<DataRow>((student) {
      List<DataCell> cells = [
        DataCell(Text(student['id'] ?? '')),
        DataCell(Text(student['name'] ?? '')),
      ];

      if (selectedType == 'project') {
        // Project evaluation cells
        cells.addAll([
          DataCell(
            SizedBox(
              width: 80,
              child: TextFormField(
                initialValue: student['topic_coverage']?.toString() ?? '',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _handleProjectScoreChange(student['id'], 'topic_coverage', value);
                },
              ),
            ),
          ),
          DataCell(
            SizedBox(
              width: 80,
              child: TextFormField(
                initialValue: student['competence']?.toString() ?? '',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _handleProjectScoreChange(student['id'], 'competence', value);
                },
              ),
            ),
          ),
          DataCell(
            SizedBox(
              width: 80,
              child: TextFormField(
                initialValue: student['language']?.toString() ?? '',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _handleProjectScoreChange(student['id'], 'language', value);
                },
              ),
            ),
          ),
          DataCell(
            SizedBox(
              width: 80,
              child: TextFormField(
                initialValue: student['delivery']?.toString() ?? '',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _handleProjectScoreChange(student['id'], 'delivery', value);
                },
              ),
            ),
          ),
          DataCell(
            SizedBox(
              width: 80,
              child: TextFormField(
                initialValue: student['time_management']?.toString() ?? '',
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  _handleProjectScoreChange(student['id'], 'time_management', value);
                },
              ),
            ),
          ),
          DataCell(Text(formData[student['id']]?['sum']?.toString() ?? student['sum']?.toString() ?? '0')),
          DataCell(Text(formData[student['id']]?['total']?.toString() ?? student['total']?.toString() ?? '0')),
        ]);
      } else {
        // Notes/Assignments cells
        final studentData = student;
        final dataKeys = studentData.keys.where((key) =>
        !['id', 'name', 'batch', 'year', 'semester'].contains(key) &&
            (selectedType == 'notes' ? key.contains('note') : key.contains('assignment'))).toList();

        for (var key in dataKeys) {
          if (selectedSubject != 'all' && !key.toLowerCase().contains(selectedSubject.toLowerCase().replaceAll(' ', '_'))) {
            continue;
          }

          if (key.endsWith('_date')) continue;

          final dateKey = key.replaceAll('_note', '_note_date').replaceAll('_assignment', '_assignment_date');
          final isChecked = formData[student['id']]?[key] == 'YES' ?? student[key] == 'YES';
          final dateValue = formData[student['id']]?[dateKey] ?? student[dateKey] ?? '';

          cells.add(DataCell(
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                  value: isChecked,
                  onChanged: (value) {
                    _handleCheckboxChange(student['id'], key, value ?? false, dateKey);
                  },
                ),
                const SizedBox(height: 5),
                SizedBox(
                  width: 120,
                  child: TextFormField(
                    enabled: isChecked,
                    initialValue: dateValue,
                    decoration: const InputDecoration(
                      labelText: 'Date',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) {
                      _handleDateChange(student['id'], dateKey, value);
                    },
                  ),
                ),
              ],
            ),
          ));
        }
      }

      return DataRow(
        cells: cells,
      );
    }).toList();
  }
}