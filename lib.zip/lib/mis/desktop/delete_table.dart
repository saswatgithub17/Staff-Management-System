import 'package:flutter/material.dart';

class DeleteTableScreen extends StatefulWidget {
  final bool isDarkMode;

  const DeleteTableScreen({super.key, required this.isDarkMode});

  @override
  State<DeleteTableScreen> createState() => _DeleteTableScreenState();
}

class _DeleteTableScreenState extends State<DeleteTableScreen> {
  String selectedBatch = 'Batch';
  String selectedYear = 'Year';
  String selectedSemester = 'Semester';

  final List<String> batches = ['Batch', '2021', '2022', '2023'];
  final List<String> years = ['Year', '1st Year', '2nd Year', '3rd Year'];
  final List<String> semesters = ['Semester', 'Sem 1', 'Sem 2', 'Sem 3'];

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDarkMode;

    return Scaffold(
      backgroundColor: isDark ? Colors.black : Colors.white,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: isDark ? Colors.black : Colors.grey[900],
            child: const Center(
              child: Text(
                "Delete Tables",
                style: TextStyle(fontSize: 22, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 24),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Colors.black87, Colors.grey]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                dropdownBox(batches, selectedBatch, (val) => setState(() => selectedBatch = val!)),
                dropdownBox(years, selectedYear, (val) => setState(() => selectedYear = val!)),
                dropdownBox(semesters, selectedSemester, (val) => setState(() => selectedSemester = val!)),
              ],
            ),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {
              // Add your delete logic here
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              elevation: 5,
              shadowColor: Colors.black,
              textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            child: const Text("Delete Table"),
          ),
        ],
      ),
    );
  }

  Widget dropdownBox(List<String> items, String selected, ValueChanged<String?> onChanged) {
    final isDark = widget.isDarkMode;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isDark ? Colors.black : Colors.white,
        border: Border.all(color: Colors.black54),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selected,
        underline: Container(),
        dropdownColor: isDark ? Colors.grey[850] : Colors.white,
        style: TextStyle(color: isDark ? Colors.white : Colors.black),
        items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
        onChanged: onChanged,
      ),
    );
  }
}
